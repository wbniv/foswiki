The following icon files come from the Tango Desktop Project [http://tango-project.org/Tango_Desktop_Project]

icon_browser.[png|svg]
icon_calendar.[png|svg]
icon_email.[png|svg]
icon_texteditor.[png|svg]
icon_update.[png|svg]
icon_users.[png|svg]

The icons are licensed under the Creative Commons Share-Alike license [http://creativecommons.org/licenses/by-sa/2.0/]
