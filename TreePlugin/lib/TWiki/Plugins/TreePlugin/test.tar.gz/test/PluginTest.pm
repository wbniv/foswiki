use lib ("./lib/");
use lib ("../../../../");

package PluginTest;
use base qw(TWikiTestCase);

use TWiki::Plugins::TreePlugin;
use TWiki;

# some helpful libs
use CGI;
use Getopt::Std;
use Cwd;
   
# load config file
do "../../../../TWiki.cfg";

use vars qw($topic, $webName, $scriptUrlPath, $userName
	%GenTests %CLOpts %OnlyTests $TestDir $OutDir $GenerateDir);

$TestDir = cwd()."/";

# change where it looks for data
$TWiki::dataDir = $TestDir."treedata/";

# where we look for comparison files
$OutDir = $TestDir."treeout/";

# whwere to put generated output files
$GenerateDir = $OutDir;

$CLOpts{"g"} = "0"; # don't know why fails without something like this
$CLOpts{"t"} = "all"; # default is to test all

getopt("gt", \%CLOpts);

%GenTests = map { $_ => 1 } split (/:/, $CLOpts{"g"} ); # if ($CLOpts{"g"});
%OnlyTests = map { $_ => 1 } split (/:/, $CLOpts{"t"} );

#print join (":", keys %GenTests), "\n";
#print join (":", keys %OnlyTests), "\n";

###### setup testing

sub new {
	my $self = shift()->SUPER::new(@_);

	# read in our test cases
	open FILE, "<testcases.txt" || warn "Couldn't open testcase file.\n";
  
	while (<FILE>) {
		my ($name, $fileout, $teststring) = split /\t/, $_, 3;
		my @a = ($fileout, $teststring);
		$this->{$name} = \@a;
	}
	#print $this->{foo}->[0], "\n";

	$self->{_generate} = \%GenTests;
	$self->{_onlytest} = \%OnlyTests;
	
	return $self;
}

####### create fixture


sub set_up {
	my $this = shift;
  
	my $url ="/twiki/bin/view";

	# create TWiki viewing params
	($topic, $webName, $scriptUrlPath, $userName ) =
		&TWiki::initialize( "/Test/WebHome", "", "", $url, new CGI );
	
	# init plugin
	TWiki::Plugins::TreePlugin::initPlugin($topic, $webName, $userName, $installWeb);

	$this->dir($OutDir);
}


######## tests

# test the set up a bit (not TWiki)

sub test_tester {
	my $this = shift;
	my $s = "this and that\n";
#	my $r = commontags($s);
	$this->assert_eq_file($s, "testest", "something wrong with testing setup");
}


sub test_blank {
	my $this = shift;
	$this->performtest(
		"blank",
		"%TREEVIEW{topic=\"\"}%"
	);
}

sub test_topic {
	my $this = shift;
	$this->performtest(
		"topic",
		"%TREEVIEW{topic=\"TheOne\"}%"
	);
}

sub test_badtopic {
	my $this = shift;
	$this->performtest(
		"badtopic",
		"%TREEVIEW{topic=\"XyyCGFGHDBND\"}%"
	);
}

#sub test_form {
#	my $this = shift;
#	$this->performtest(
#		"form",
#		"%TREEVIEW{form=\"TestForm\"}%"
#	);
#}

sub test_formatting_ullist {
	my $this = shift;
	$this->performtest(
		"formatting-ullist",
		"%TREEVIEW{formatting=\"ullist\"}%"
	);
}

sub test_formatting_ollist {
	my $this = shift;
	$this->performtest(
		"formatting-ollist",
		"%TREEVIEW{formatting=\"ollist\"}%"
	);
}

sub test_formatting_outline {
	my $this = shift;
	$this->performtest(
		"formatting-outline",
		"%TREEVIEW{formatting=\"outline\"}%"
	);
}

sub test_formatting_hlist {
	my $this = shift;
	$this->performtest(
		"formatting-hlist",
		"%TREEVIEW{formatting=\"hlist\"}%");
}

sub test_formatting_colorout {
	my $this = shift;
	$this->performtest(
		"formatting-colorout","%TREEVIEW{formatting=\"coloroutline\"}%"
	);
}

sub test_format_colorlevel {
	my $this = shift;
	$this->performtest(
		"format-colorlevel",
		"%TREEVIEW{formatting=\"coloroutline\" format=\"\$level \"}%"
	);
}

sub test_format_colorlevel_onearg {
	my $this = shift;
	$this->performtest(
		"format-colorlevel_onearg",
		"%TREEVIEW{formatting=\"coloroutline:#ffeeff\" format=\"\$level \"}%"
	);
}

sub test_format_colorlevel_args {
	my $this = shift;
	$this->performtest(
		"format-colorlevel_args","%TREEVIEW{formatting=\"coloroutline:#ffeeff:green:#aabfdc\" format=\"\$level \"}%"
	);
}

sub test_format {
	my $this = shift;
	$this->performtest(
		"format-foo",
		"%TREEVIEW{format=\"foo, \"}%");
}

sub test_format_onum {
	my $this = shift;
	$this->performtest(
		"format-onum",
		"%TREEVIEW{format=\"\$outnum, \"}%");
}

sub test_format_level {
	my $this = shift;
	$this->performtest(
		"format-level",
		"%TREEVIEW{format=\"\$level, \"}%");
}

sub test_format_count {
	my $this = shift;
	$this->performtest(
		"format-count",
		"%TREEVIEW{format=\"\$count, \"}%");
}

sub test_format_topic {
	my $this = shift;
	$this->performtest(
		"format-topic",
		"%TREEVIEW{format=\"\$topic, \"}%");
}

sub test_format_spacetopic {
	my $this = shift;
	$this->performtest(
		"format-spacetopic",
		"%TREEVIEW{format=\"\$spacetopic, \"}%");
}


sub test_format_author {
	my $this = shift;
	$this->performtest(
		"format-author",
		"%TREEVIEW{format=\"\$author, \"}%");
}


sub test_format_modtime {
	my $this = shift;
	$this->performtest(
		"format-modTime",
		"%TREEVIEW{format=\"\$modTime, \"}%");
}

# not useful
sub test_format_url {
	my $this = shift;
	$this->performtest(
		"format-url","%TREEVIEW{format=\"\$url, \"}%");
}

sub test_format_web {
	my $this = shift;
	$this->performtest(
		"format-web",
		"%TREEVIEW{format=\"\$web, \"}%");
}

sub test_format_summary {
	my $this = shift;
	$this->performtest(
		"format-summary",
		"%TREEVIEW{format=\"\$summary, \"}%");
}

sub test_format_text {
	my $this = shift;
	$this->performtest(
		"format-text",
		"%TREEVIEW{format=\"\$text\"}%");
}

sub test_formatbranch {
	my $this = shift;
	$this->performtest(
		"formatbranch","%TREEVIEW{formatbranch=\"goo, \"}%");
}

sub test_formatbranch_parent {
	my $this = shift;
	$this->performtest(
		"formatbranch-parent",
		"%TREEVIEW{formatbranch=\"\$parent, \"}%");
}

sub test_formatbranch_children {
	my $this = shift;
	$this->performtest(
		"formatbranch-children",
		"%TREEVIEW{formatbranch=\"\$children, \"}%");
}


sub test_formatbranch_parentchildren {
	my $this = shift;
	$this->performtest(
		"formatbranch-parentchildren",
		"%TREEVIEW{formatbranch=\"\$parent: \$children \"}%");
}

sub test_formatbranch_format {
	my $this = shift;
	$this->performtest(
		"formatbranch-format",		"%TREEVIEW{format=\"\$topic <br>\" formatbranch=\"\$parent \$children <p>\"}%");
}


sub test_stoplevel {
	my $this = shift;
	$this->performtest(
		"stoplevel","%TREEVIEW{stoplevel=\"3\"}%");
}

sub test_header {
	my $this = shift;
	$this->performtest(
		"header","%TREEVIEW{header=\"HEADER TEXT\"}%");
}


sub test_bookview {
	my $this = shift;
	$this->performtest(
		"bookview","%TREEVIEW{bookview=\"on\"}%");
}

#	this is an indirect test for recursion
#   (the same topic's TREEVIEW called twice on same page)

sub test_doublecall_same {
	my $this = shift;
	$this->performtest(
		"doublecall-same","%TREEVIEW{topic=\"TheOne\"}%");
	$this->performtest(
		"doublecall-second","%TREEVIEW{topic=\"TheOne\"}%");
}

#	make sure we can call different topics on same page
sub test_doublecall {
	my $this = shift;
	$this->performtest(
		"doublecall","%TREEVIEW{topic=\"TheOne\"}%");
	$topic = "TheTwo";
	$this->performtest(
		"doublecall-diff","%TREEVIEW{topic=\"TheTwo\"}%");
}

########### helper funcs

sub performtest {
	my ($this, $f, $what) = @_;
	my $input = $what; # copy tag text before it gets changed
	commontags($what);
	return if ($this->generate($what, $f));
	return if ($this->onlytest($what, $f));	
	$this->assert_eq_file($what, $f.".html", "failure on: $input\n");
}

sub commontags {
	TWiki::Plugins::TreePlugin::commonTagsHandler(shift, $topic, $webName);
}

sub generate {
	my ($this, $text, $filename ) = @_;
	my $gentests = $this->{_generate}; 
	return 0 unless ( %{$gentests});
	return 0 unless ( $gentests->{$filename} || $gentests->{"all"} );
	
	open FILE, ">$GenerateDir".$filename.".html" || die "open error";
	print FILE $text;
}

sub onlytest {
	my ($this, $text, $filename ) = @_;
	my $onlytest = $this->{_onlytest};
	return 1 unless ( %{$onlytest});
	return 0 if ( $onlytest->{$filename} || $onlytest->{"all"} );
	return 1;
}



#create_suite();
#run_suite();


#$query = new CGI( {'dinosaur'=>'barney',
#                       'song'=>'I love you',
#                       'friends'=>[qw/Jessica George Nancy/]}
#                    );


__END__
