use lib ("./lib/");
use lib ("../../../../");

use TWiki::Plugins::TreePlugin;
use TWiki::Store;
use TWiki::Meta;
use TWiki::Func;
use TWiki;

use TWikiTestCase;
use Test::Unit;

use CGI;

do "../../../../TWiki.cfg";

# change where it looks for data

# $dataDir="./treedata/";

$TWiki::dataDir          = "./treedata";

use vars qw($t $topic $webName $scriptUrlPath $userName );

#$query = new CGI( {'dinosaur'=>'barney',
#                       'song'=>'I love you',
#                       'friends'=>[qw/Jessica George Nancy/]}
#                    );
                    
sub set_up {
	$t = TWikiTestCase->new();
	my $url ="http://zoopy.mine.nu:9090/twiki/bin/view";


	($topic, $webName, $scriptUrlPath, $userName ) =
		&TWiki::initialize( "/Test/WebHome", "", "", $url, new CGI );
	
	TWiki::Plugins::TreePlugin::initPlugin($topic, $webName, $userName, $installWeb);

	print "$topic|$webName|$scriptUrlPath|$userName";
#	my $s = "%CREATECHILD%";
#	my $r = TWiki::Plugins::TreePlugin::commonTagsHandler($s, $topic, $webName);
	
#	print "|$r|", $s, "|\n";
	
	$t->dir("testdata/");
}

sub commontags {
	TWiki::Plugins::TreePlugin::commonTagsHandler(shift, $topic, $webName);
}

sub test_foo {
	my $s = "%TREESEARCH{topic=\"\"}%";

	my $r = commontags($s);
	
	$t->assert_eq_file ($s, "out", "nope.");
	
#	open FILE, ">out" || die "open error";
#	print FILE $s;
}

create_suite();
run_suite();







