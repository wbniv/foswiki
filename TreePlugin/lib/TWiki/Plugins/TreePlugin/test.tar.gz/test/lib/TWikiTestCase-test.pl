use lib ("./");

use TWikiTestCase;
use Test::Unit;

use vars qw($t $f);

#$t->assert_cmp_file("", "testcase.txt", "message");

#$t->assert_cmp_file(" ", "testcase.txt", "message");


sub set_up {
	$t = TWikiTestCase->new();
	$t->dir("foo/");
	$f = "testcase.txt";
}

sub test_eq {
	$t->assert_eq_file("foo bar this that", $f, "Your message here");
}

sub test_ne {
	$t->assert_ne_file(" ", $f, "Your message here");
}

sub test_match {
	$t->assert_match_file("foo", $f, "Your message here");
}

sub test_nmatch {
	$t->assert_nmatch_file("qwe", $f, "Your message here");
}

sub test_badfile {
	$t->assert_match_file("", $f, "Your message here");
}


create_suite();
run_suite();


