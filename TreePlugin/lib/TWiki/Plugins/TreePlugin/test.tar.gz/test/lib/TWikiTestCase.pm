
package TWikiTestCase;
use base qw(Test::Unit::TestCase);

use Test::Unit;

sub new {
  my $this = shift()->SUPER::new(@_);
  return $this;
}

sub dir {
    my $this = shift;
    if (@_) { $this->{_dir} = shift; };
    return $this->{_dir};
}

sub assert_eq_file {
	my ($this, $text, $filename, $message) = @_;
	my $filetext = $this->_getFileText($filename);
	assert($text eq $filetext, $message);
}

sub assert_ne_file {
	my ($this, $text, $filename, $message) = @_;
	my $filetext = $this->_getFileText($filename);
	assert($text ne $filetext, $message);
}

sub assert_match_file {
	my ($this, $text, $filename, $message) = @_;
	my $filetext = $this->_getFileText($filename);
	assert($text =~ /$filetext/, $message);
}

sub assert_nmatch_file {
	my ($this, $text, $filename, $message) = @_;
	my $filetext = $this->_getFileText($filename);
	assert( $text !~ /$filetext/, $message);
}


sub _getFileText {
	my ($this, $filename) = @_;
	my $filename = $this->dir().$filename;
	my $text;
	open FILE, "<$filename" || return $this->handleFE($filename);

    #my $fh = \*FILE;
	my $eolsave = $/;
    undef $/; 				# set EOL to read files to EOF
    eval { $text= <FILE>} ; # grab whole file
    $/ = $eolsave; 			# reset EOL back

	# we could still have an error now!
#	return $this->handleFE($filename)
#		if ( $! || $@ );
	return $text;
}

sub handleFE {
	my ($this, $file) = @_;
	my $fileerror = $@ || $!;
	$@ = ""; # reset 
	$! = "";
	return $this->assert(0, "Failed to read comparison file: $file with error: $fileerror");
}

1;


__END__


use lib ("./");
use lib ("../lib/TWiki/Plugins/TreePlugin");

use TWikiTestCase;
use Test::Unit;

use vars qw($t $f);


sub set_up {
	$t = TWikiTestCase->new();
	$t->dir("foo/");
	$f = "testcase.txt";
}

sub test_eq {
	$t->assert_eq_file("foo bar this that", $f, "Your message here");
}

sub test_ne {
	$t->assert_ne_file(" ", $f, "Your message here");
}

sub test_match {
	$t->assert_match_file("", $f, "Your message here");
}


sub test_badfile {
	$t->assert_match_file("", "txt", "Your message here");
}


create_suite();
run_suite();


