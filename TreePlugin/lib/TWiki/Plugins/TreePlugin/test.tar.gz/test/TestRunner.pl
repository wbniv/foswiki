#!perl
use lib ("./");
use Test::Unit::TestRunner;
use PluginTest;

my $testrunner = Test::Unit::TestRunner->new();
$testrunner->start(PluginTest);


